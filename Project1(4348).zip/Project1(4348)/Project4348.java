//Riyasat Rashid
//4-28-24


import java.io.*;

public class Project4348 {

    public static void main(String[] args) {
        // Check if the correct number of arguments is provided
        if (args.length != 1) {
            System.err.println("Usage: java Project4348 <process_type>");
            System.err.println("process_type: parent | child1 | child2");
            System.exit(1);
        }

        // Get the process type from the command line argument
        String processType = args[0];

        // Create a new process based on the process type
        if (processType.equals("parent")) {
            parentProcess();
        } else if (processType.equals("child1")) {
            child1Process();
        } else if (processType.equals("child2")) {
            child2Process();
        } else {
            System.err.println("Invalid process type: " + processType);
            System.exit(1);
        }
    }

    // Parent process method
    private static void parentProcess() {
        try {
            // Create pipes for communication with child processes
            Pipe pipe1 = new Pipe();
            Pipe pipe2 = new Pipe();

            // Create child processes
            Process child1 = Runtime.getRuntime().exec(new String[]{"java", "Project4348", "child1"}, null, new File("."));
            Process child2 = Runtime.getRuntime().exec(new String[]{"java", "Project4348", "child2"}, null, new File("."));

            // Write file names to the pipes
            PrintWriter out1 = new PrintWriter(pipe1.getOutputStream());
            PrintWriter out2 = new PrintWriter(pipe2.getOutputStream());
            out1.println("d1/f1");
            out1.println("d1/f2");
            out1.flush();
            out2.println("d2/f3");
            out2.println("d2/f4");
            out2.flush();

            // Read data from the files in d0 and send to child processes
            BufferedReader in1 = new BufferedReader(new FileReader("d0/f1"));
            BufferedReader in2 = new BufferedReader(new FileReader("d0/f2"));
            BufferedReader in3 = new BufferedReader(new FileReader("d0/f3"));
            BufferedReader in4 = new BufferedReader(new FileReader("d0/f4"));
            OutputStream child1Out = child1.getOutputStream();
            OutputStream child2Out = child2.getOutputStream();
            String line;
            while ((line = in1.readLine()) != null) {
                child1Out.write((line + "\n").getBytes());
            }
            while ((line = in2.readLine()) != null) {
                child1Out.write((line + "\n").getBytes());
            }
            while ((line = in3.readLine()) != null) {
                child2Out.write((line + "\n").getBytes());
            }
            while ((line = in4.readLine()) != null) {
                child2Out.write((line + "\n").getBytes());
            }

            // Close input and output streams
            in1.close();
            in2.close();
            in3.close();
            in4.close();
            out1.close();
            out2.close();
            child1Out.close();
            child2Out.close();

            // Wait for child processes to finish
            child1.waitFor();
            child2.waitFor();

            System.out.println("Parent process finished.");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Child 1 process method
    private static void child1Process() {
        try {
            // Create a pipe for communication with the parent process
            Pipe pipe = new Pipe();

            // Read file names from the pipe
            BufferedReader in = new BufferedReader(new InputStreamReader(pipe.getInputStream()));
            String f1Name = in.readLine();
            String f2Name = in.readLine();

            // Create files with the received names
            PrintWriter out1 = new PrintWriter(new FileWriter(f1Name));
            PrintWriter out2 = new PrintWriter(new FileWriter(f2Name));

            // Read data from the pipe and write to the files
            BufferedReader pipeIn = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = pipeIn.readLine()) != null) {
                out1.println(line);
                out2.println(line);
            }

            // Close input and output streams
            in.close();
            out1.close();
            out2.close();
            pipeIn.close();

            System.out.println("Child 1 process finished.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Child 2 process method
    private static void child2Process() {
        try {
            // Create a pipe for communication with the parent process
            Pipe pipe = new Pipe();

            // Read file names from the pipe
            BufferedReader in = new BufferedReader(new InputStreamReader(pipe.getInputStream()));
            String f3Name = in.readLine();
            String f4Name = in.readLine();

            // Create files with the received names
            PrintWriter out1 = new PrintWriter(new FileWriter(f3Name));
            PrintWriter out2 = new PrintWriter(new FileWriter(f4Name));

            // Read data from the pipe and write to the files
            BufferedReader pipeIn = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = pipeIn.readLine()) != null) {
                out1.println(line);
                out2.println(line);
            }

            // Close input and output streams
            in.close();
            out1.close();
            out2.close();
            pipeIn.close();

            System.out.println("Child 2 process finished.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Pipe class implementation
    private static class Pipe {
        private PipedInputStream inputStream;
        private PipedOutputStream outputStream;

        public Pipe() throws IOException {
            inputStream = new PipedInputStream();
            outputStream = new PipedOutputStream(inputStream);
        }

        public InputStream getInputStream() {
            return inputStream;
        }

        public OutputStream getOutputStream() {
            return outputStream;
        }
    }
}
